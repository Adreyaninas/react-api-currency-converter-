export const language = [
    { code: "USD" },
    { code: "EUR" },
    { code: "PHP" },
    { code: "AUD" },
    { code: "INR" },
    { code: "NZD" },
    { code: "JPY" }
]